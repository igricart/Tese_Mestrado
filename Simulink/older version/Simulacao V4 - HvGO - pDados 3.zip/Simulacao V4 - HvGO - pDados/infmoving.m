function saida=infmoving(u)
global buffer3


%  

buffer3=wshift('1D',buffer3,1);
buffer3(end)=abs(u);
saida=min(buffer3);


end
