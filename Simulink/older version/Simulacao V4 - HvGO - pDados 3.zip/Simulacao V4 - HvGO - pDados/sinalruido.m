function saida=sinalruido(u)
global buffersup bufferinf


%  

buffersup=wshift('1D',buffersup,1);
buffersup(end)=abs(u);
sup=max(buffersup);



bufferinf=wshift('1D',bufferinf,1);
bufferinf(end)=abs(u);
inf=min(bufferinf);

ruido=abs(sup-inf);
sinal=abs(mean([sup inf]));


% O ruido nao pode ser mais da metade do sinal --> N<S/2 --> N/S<1/2=maxNSR
% 
maxNSR=1/2;
if (sinal==0)
    if (ruido==0) 
        NSR=0;
    else
        NSR=maxNSR;
    end
else
    NSR=ruido/sinal;
    if (NSR>1/2) NSR=1/2;
    end
end

saida=[NSR sinal sup inf ruido];

end
