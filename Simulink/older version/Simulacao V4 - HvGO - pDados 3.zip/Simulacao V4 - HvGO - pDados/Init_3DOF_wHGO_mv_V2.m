clear all; clc;

global buffer2 buffer3
global buffersup bufferinf bufferNSR

numBodies = 4;
numJoints = numBodies - 1;

%% Body 0 fixed (support)
eta_0bar = zeros(6,1); 
V_0bar = zeros(6,1);
dV_0bar = zeros(6,1);

%% Masses
m0 = 0;
m1 = 21.29;
m2 = 8.57;
m3 = 2.33;

Mass = [m0 m1 m2 m3];

%% Inertia parameters
I0 = [0 0 0];
I1 = [0 0 0];
I2 = [0 0.435 0];
I3 = [0 0.062 0];

Inertia = [I0 I1 I2 I3];

%% Transla??o dos frames das juntas
% Joint positions (from robot geometry)
d0 = 0.5;
L2 = 0.425;
L3 = 0.527;
C2 = -0.339;
C3 = 0.320;

l2 = L2;
l3 = L3;
l_0bar1bar = zeros(3,1);
l_1bar2bar = [ 0 -d0 0 ]';
l_2bar3bar = [ 0 0 l2 ]';
l_3bar4bar = [ 0 0 l3 ]';
L = [ l_0bar1bar l_1bar2bar l_2bar3bar l_3bar4bar ];

r2 = L2 + C2;
r3 = C3;
%% Transla??o dos frames no centro de massa
r_0bar0 = zeros(3,1);
r_1bar1 = zeros(3,1);
r_2bar2 = [ 0 0 r2 ]';
r_3bar3 = [ 0 0 r3 ]';
R = [ r_0bar0 r_1bar1 r_2bar2 r_3bar3 ];

JointTypes = ['p','r','r'];
ANG_OFFSET_CM = zeros(3,4);
g = 9.81;
ex = [1;0;0]; ey = [0;1;0]; ez = [0;0;1];
G = g*ez;
Axis = [ ez -ey -ey ];
Friction_torques = zeros(numJoints,1);

%% Initial state
%qInit = [0 45*pi/180 45*pi/180]';
qInit = [0 5*pi/180 0*45*pi/180]';
%qInit = [0 5*pi/180 5*pi/180]';
%qInit = 100*[10 3*45*pi/180 3*45*pi/180]';
dqInit = 0*[5 -5 5]';

%% CTPD Gains
kp = 5*2; %100
kd = 10*2; %10
Kp = kp*eye(3);
Kd = kd*eye(3);

%% Joint reference values
A = 1;
w = 1.5*pi;
offset = 0;

%%HGO1
Mu1 = 1e-3;

A01 = [0 1; 0 0];
B01 = [0;1];
C01 = [1 0];
Hmu1 = [1/Mu1 0;0 1/(Mu1^2)];
aa=10;
L01= [2*aa;aa*aa];


%%HGO2
Mu2 = 1e-3;

A02 = [0 1; 0 0];
B02 = [0;1];
C02 = [1 0];
Hmu2 = [1/Mu2 0;0 1/(Mu2^2)];
aa=5;
L02= [2*aa;aa*aa];

%%HGO3
Mu3 = 1e-3;

A03 = [0 1; 0 0];
B03 = [0;1];
C03 = [1 0];
Hmu3 = [1/Mu3 0;0 1/(Mu3^2)];
aa=5;
L03= [2*aa;aa*aa];

passo = 1e-4;


Ar = [zeros(3) eye(3); zeros(3) zeros(3)];
Br = [zeros(3); eye(3)];
Cr = [eye(3) zeros(3)];

P = conv(conv([1 2 1],[1 2 1]),[1 2 1]);

Lc1 = [P(2:end)]';
Lc2 = [P(2:end)]';
Lc3 = [P(2:end)]';
%L1 = [Lc1 Lc2 Lc3];

Mu = 1e-3;

L = [eye(3);2*eye(3)];

Hmu = [eye(3)/Mu zeros(3); zeros(3) eye(3)/Mu^2];

kpn = eye(3);

buffer2=zeros(0.0005/passo,1);
buffer3=zeros(0.0005/passo,1);

buffersup=zeros(0.0005/passo,1);
bufferinf=zeros(0.0005/passo,1);
bufferNSR=zeros(0.05/passo,1);


e1=0.8;e2=0.1;
y1=0.1/8;y2=0.1;
aux=inv([e1 1;e2 1])*[y1 y2]';
mua=aux(1);
mub=aux(2);


