t=vq1.time;
q1ref = vq1.signals.values(:,1);
q1 = vq1.signals.values(:,2);
q1est = vq1.signals.values(:,3);

q2ref = vq2.signals.values(:,1);
q2 = vq2.signals.values(:,2);
q2est = vq2.signals.values(:,3);

q3ref = vq3.signals.values(:,1);
q3 = vq3.signals.values(:,2);
q3est = vq3.signals.values(:,3);

t2 = Mu.time;
Mu = Mu.signals.values(:,1);

%Estados q

figure(1);
subplot(1,2,1);
plot(t,q1,t,q1est,'--');
grid;
xlabel('time(s)');
ylabel('Hip displacement (m)');
xlim([0 1]);
legend('True','Estimated');
title('Hip displacement (m)');

subplot(1,2,2);
plot(t,q1,t,q1est,'--');
grid;
xlabel('time(s)');
ylabel('Hip displacement (m)');
xlim([0 0.03]);
legend('True','Estimated');
title('Zoom');

figure(2);
subplot(1,2,1);
plot(t,q2,t,q2est,'--');
grid;
xlabel('time(s)');
ylabel('Thigh angle (rad)');
xlim([0 1]);
legend('True','Estimated');
title('Thigh angle (rad)');

subplot(1,2,2);
plot(t,q2,t,q2est,'--');
grid;
xlabel('time(s)');
ylabel('Thigh angle (rad)');
xlim([0 0.015]);
legend('True','Estimated');
title('Zoom');

figure(3);
subplot(1,2,1);
plot(t,q3,t,q3est,'--');
grid;
xlabel('time(s)');
ylabel('Knee angle (rad)');
xlim([0 1]);
legend('True','Estimated');
title('Knee angle (rad)');


subplot(1,2,2);
plot(t,q3,t,q3est,'--');
grid;
xlabel('time(s)');
ylabel('Knee angle (rad)');
xlim([0 0.02]);
legend('True','Estimated');
title('Zoom');

%Estados dq

dq1ref = vdq1.signals.values(:,1);
dq1 = vdq1.signals.values(:,2);
dq1est = vdq1.signals.values(:,3);

dq2ref = vdq2.signals.values(:,1);
dq2 = vdq2.signals.values(:,2);
dq2est = vdq2.signals.values(:,3);

dq3ref = vdq3.signals.values(:,1);
dq3 = vdq3.signals.values(:,2);
dq3est = vdq3.signals.values(:,3);


figure(4);
subplot(1,2,1);
plot(t,dq1,t,dq1est,'--');
ylim([-0.4 0.4]);
xlim([0 1]);
grid;
xlabel('time(s)');
ylabel('Hip velocity (m/s)');
legend('True','Estimated');
title('Hip velocity (m/s)');

subplot(1,2,2);
plot(t,dq1,t,dq1est,'--');
grid;
xlabel('time(s)');
ylabel('Hip velocity (m/s)');
xlim([0 0.03]);
legend('True','Estimated');
title('Zoom');

figure(5);
subplot(1,2,1);
plot(t,dq2,t,dq2est,'--');
grid;
xlabel('time(s)');
ylabel('Angular velocity of thigh (rad/s)');
xlim([0 1]);
ylim([-5 15]);
legend('True','Estimated');
title('Angular velocity of thigh (rad/s)');

subplot(1,2,2);
plot(t,dq2,t,dq2est,'--');
grid;
xlabel('time(s)');
ylabel('Angular velocity of thigh (rad/s)');
xlim([0 0.05]);
legend('True','Estimated');
title('Zoom');

figure(6);
subplot(1,2,1);
plot(t,dq3,t,dq3est,'--');
grid;
xlabel('time(s)');
ylabel('Angular velocity of knee (rad/s)');
xlim([0 1]);
ylim([-15 15]);
legend('True','Estimated');
title('Angular velocity of knee (rad/s)');

subplot(1,2,2);
plot(t,dq3,t,dq3est,'--');
grid;
xlabel('time(s)');
ylabel('Angular velocity of knee (rad/s)');
xlim([0 0.05]);
legend('True','Estimated');
title('Zoom');

figure(7);
%subplot(1,2,1);
plot(t2,Mu);
grid;
xlabel('time(s)');
ylabel('Mu');
xlim([0 10]);
ylim([-0.05 0.15]);
legend('Mu');
title('Mu');